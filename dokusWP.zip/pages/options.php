<?php
/**
 * Created by Sindre Svendby
 * License under common sense and respect.
 */
 
$options = get_option(WP_OPTION_KEY);
print_array($options);