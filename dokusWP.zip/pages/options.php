<?php
 
$options = get_option(WP_OPTION_KEY);
print_array($options);