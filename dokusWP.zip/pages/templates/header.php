<div class="header">
    <ul class="dokus_wp_menu">
        <li class="dokus_wp_menu">
            <a href="<?= DOKUS_ADMIN_URL ?>">Main Page</a>
        </li>
        <li class="dokus_wp_menu">
            <a href="<?= DOKUS_ADMIN_URL . '&' . DOKUS_PAGE . '=' . SEE_SETTINGS ?>">Settings </a>
        </li>
        <li class="dokus_wp_menu">
            <a href="<?= DOKUS_ADMIN_URL . '&' . DOKUS_PAGE . '=options' ?>">See saved options </a>
        </li>
        <li class="dokus_wp_menu">
            <a href="<?= DOKUS_ADMIN_URL . '&' . DOKUS_PAGE . '=' . SEE_DOKUS_USERS ?>">Dokus users </a>
        </li>
        <li class="dokus_wp_menu">
            <a href="<?= DOKUS_ADMIN_URL . '&' . DOKUS_PAGE . '=' . SEE_WORDPRESS_USERS ?>">Wordpress users </a>
        </li>
        <li class="dokus_wp_menu">
            <a href="<?= DOKUS_ADMIN_URL . '&' . DOKUS_PAGE . '=' . "mapping_users" ?>">Mapping users</a>
        </li>
    </ul>
</div>