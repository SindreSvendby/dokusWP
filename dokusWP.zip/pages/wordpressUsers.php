<?php
/**
 * Created by Sindre Svendby
 * License under common sense and respect.
 */
 
$users = get_users();
print_array($users);