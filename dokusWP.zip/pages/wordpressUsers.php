<?php
$users = get_users();
print_array($users);