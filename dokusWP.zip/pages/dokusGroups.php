<?php

$groups = $dokus->customerGroups->all();
print_array($groups);
?>