<?php
/**
 * Created by Sindre Svendby
 * License under common sense and respect.
 */

$groups = $dokus->customerGroups->all();
print_array($groups);
?>