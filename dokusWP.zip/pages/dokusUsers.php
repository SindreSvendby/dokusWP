<?php
/**
 * Created by Sindre Svendby
 * License under common sense and respect.
 */
 

$users = $dokus->customers->all();
print_array($users);
?>