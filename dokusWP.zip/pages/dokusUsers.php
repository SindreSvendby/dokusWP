<?php

$users = $dokus->customers->all();
print_array($users);
?>